import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { VideosRoutingModule } from './videos-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    VideosRoutingModule
  ]
})
export class VideosModule { }
