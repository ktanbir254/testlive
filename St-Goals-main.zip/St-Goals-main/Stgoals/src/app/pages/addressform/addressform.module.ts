import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AddressformRoutingModule } from './addressform-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    AddressformRoutingModule
  ]
})
export class AddressformModule { }
