import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addressform',
  templateUrl: './addressform.component.html',
  styleUrls: ['./addressform.component.scss']
})
export class AddressformComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
