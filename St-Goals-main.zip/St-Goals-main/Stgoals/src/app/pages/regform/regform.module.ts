import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RegformRoutingModule } from './regform-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RegformRoutingModule
  ]
})
export class RegformModule { }
