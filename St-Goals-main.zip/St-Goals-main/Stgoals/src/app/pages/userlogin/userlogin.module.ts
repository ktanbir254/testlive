import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserloginRoutingModule } from './userlogin-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    UserloginRoutingModule
  ]
})
export class UserloginModule { }
