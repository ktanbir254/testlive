import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { OtpformRoutingModule } from './otpform-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    OtpformRoutingModule
  ]
})
export class OtpformModule { }
