import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-otpform',
  templateUrl: './otpform.component.html',
  styleUrls: ['./otpform.component.scss']
})
export class OtpformComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
